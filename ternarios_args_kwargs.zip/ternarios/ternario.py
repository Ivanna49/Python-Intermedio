"""edad = 18

print("Es mayor de edad" if edad >= 18 else "Es menor de edad")

mostrar_edad = "Es mayor de edad" if edad >= 18 else "Es menor de edad"

print(mostrar_edad)
"""

a = 1
b = 3
c = 2

numero_mayor = a if a > b and a > c else b if b > c else c

print(numero_mayor)