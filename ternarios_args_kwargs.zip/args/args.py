"""def test_var_args(f_arg,*argv ):
    print("primer argumento normal:", f_arg)
    print(argv) #esto regresa una tupla
    for arg in argv:
        print("argumentos de *argv:", arg)

test_var_args('python','foo', 'bar', "hola", "argumento")


"""
def saludame(**kwargs):
    print(kwargs) #esto nos regresa un diccionario
    for key, value in kwargs.items():
        print("{0} = {1}".format(key, value))

saludame(nombre = "Gabriel", apellido = "Gomez", provincia = "Buenos Aires")

